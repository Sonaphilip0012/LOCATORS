declare namespace NodeJS {
  interface ProcessEnv {
    NEXT_PUBLIC_INFURA_ID: string;
    NEXT_PUBLIC_INFURA_SECRET_KEY: string;
  }
}
